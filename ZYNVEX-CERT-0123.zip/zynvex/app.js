// app.js — Mood Recipe Finder logic

(function () {
  "use strict";

  /* ── DOM refs ────────────────────────────────────── */
  const moodGrid      = document.getElementById("moodGrid");
  const recipeSection = document.getElementById("recipeSection");
  const recipeHeading = document.getElementById("recipeHeading");
  const recipeSub     = document.getElementById("recipeSubheading");
  const recipeGrid    = document.getElementById("recipeGrid");
  const loadingBar    = document.getElementById("loadingBar");
  const bgWash        = document.getElementById("bgWash");
  const modalOverlay  = document.getElementById("modalOverlay");
  const modalClose    = document.getElementById("modalClose");
  const modalInner    = document.getElementById("modalInner");

  let activeMood = null;
  let loadingTimer = null;

  /* ── Build mood orbs ─────────────────────────────── */
  MOODS.forEach(mood => {
    const btn = document.createElement("button");
    btn.className = "mood-orb";
    btn.setAttribute("aria-label", mood.label);
    btn.dataset.id = mood.id;

    btn.innerHTML = `
      <div class="orb-circle" style="
        background: ${mood.bg};
        --orb-color: ${mood.color};
      ">${mood.emoji}</div>
      <span class="orb-label">${mood.label}</span>
    `;

    btn.addEventListener("click", () => selectMood(mood));
    moodGrid.appendChild(btn);
  });

  /* ── Select mood ─────────────────────────────────── */
  function selectMood(mood) {
    if (activeMood === mood.id) return;
    activeMood = mood.id;

    // Update active orb
    document.querySelectorAll(".mood-orb").forEach(b => {
      b.classList.toggle("active", b.dataset.id === mood.id);
    });

    // Shift background wash
    const data = RECIPES[mood.id];
    bgWash.style.background = data.bgWash;

    // Show section & loading
    recipeSection.classList.add("visible");
    recipeGrid.innerHTML = "";
    recipeHeading.textContent = "";
    recipeSub.textContent = "";
    loadingBar.classList.add("active");

    // Simulate brief AI loading feel
    clearTimeout(loadingTimer);
    loadingTimer = setTimeout(() => {
      loadingBar.classList.remove("active");
      renderRecipes(mood.id);
    }, 900);

    // Scroll into view
    setTimeout(() => {
      recipeSection.scrollIntoView({ behavior: "smooth", block: "start" });
    }, 100);
  }

  /* ── Render recipe cards ─────────────────────────── */
  function renderRecipes(moodId) {
    const data = RECIPES[moodId];
    recipeHeading.textContent = data.heading;
    recipeSub.textContent = data.subheading;

    data.items.forEach((recipe, i) => {
      const card = document.createElement("div");
      card.className = "recipe-card";
      card.style.animationDelay = `${i * 0.12}s`;

      const gradients = [
        "linear-gradient(135deg,#1c1730,#2a1f4a)",
        "linear-gradient(135deg,#1a1f30,#1e2a3a)",
        "linear-gradient(135deg,#1f1a30,#2a1a35)",
      ];

      card.innerHTML = `
        <div class="card-emoji" style="background:${gradients[i % gradients.length]}">
          ${recipe.emoji}
          <span class="card-badge">${recipe.category}</span>
        </div>
        <div class="card-body">
          <div class="card-name">${recipe.name}</div>
          <div class="card-desc">${recipe.desc}</div>
          <div class="card-meta">
            <span>⏱ ${recipe.time}</span>
            <span>👤 Serves ${recipe.serves}</span>
            <span>⭐ ${recipe.difficulty}</span>
          </div>
          <span class="card-cta">View Recipe →</span>
        </div>
      `;

      card.addEventListener("click", () => openModal(recipe));
      recipeGrid.appendChild(card);
    });
  }

  /* ── Modal ───────────────────────────────────────── */
  function openModal(recipe) {
    const gradients = [
      "linear-gradient(135deg,#1c1730,#3d2060)",
      "linear-gradient(135deg,#1a2030,#1e3a4a)",
      "linear-gradient(135deg,#1f1530,#3a1a50)",
    ];
    const grad = gradients[Math.floor(Math.random() * gradients.length)];

    modalInner.innerHTML = `
      <div class="modal-emoji-header" style="background:${grad}">
        ${recipe.emoji}
      </div>
      <div class="modal-body">
        <div class="modal-category">${recipe.category}</div>
        <div class="modal-title">${recipe.name}</div>
        <div class="modal-desc">${recipe.desc}</div>

        <div class="modal-meta-row">
          <div class="modal-meta-item">
            <span class="label">Time</span>
            <span class="value">⏱ ${recipe.time}</span>
          </div>
          <div class="modal-meta-item">
            <span class="label">Serves</span>
            <span class="value">👤 ${recipe.serves}</span>
          </div>
          <div class="modal-meta-item">
            <span class="label">Difficulty</span>
            <span class="value">⭐ ${recipe.difficulty}</span>
          </div>
        </div>

        <div class="modal-section-title">Ingredients</div>
        <ul class="ingredients-list">
          ${recipe.ingredients.map(ing => `<li>${ing}</li>`).join("")}
        </ul>

        <div class="modal-section-title">Method</div>
        <ol class="steps-list">
          ${recipe.steps.map((step, i) => `
            <li>
              <span class="step-num">${i + 1}</span>
              <span>${step}</span>
            </li>
          `).join("")}
        </ol>
      </div>
    `;

    modalOverlay.classList.add("open");
    document.body.style.overflow = "hidden";
  }

  function closeModal() {
    modalOverlay.classList.remove("open");
    document.body.style.overflow = "";
  }

  modalClose.addEventListener("click", closeModal);
  modalOverlay.addEventListener("click", e => {
    if (e.target === modalOverlay) closeModal();
  });
  document.addEventListener("keydown", e => {
    if (e.key === "Escape") closeModal();
  });

})();