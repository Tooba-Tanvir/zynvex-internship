// data.js — Mood-based recipe data

const MOODS = [
  { id: "happy",     emoji: "😄", label: "Happy",     color: "#f5c842", bg: "linear-gradient(135deg,#f5c842,#ff9f43)" },
  { id: "cozy",      emoji: "🤗", label: "Cozy",      color: "#e07b54", bg: "linear-gradient(135deg,#e07b54,#c0392b)" },
  { id: "energized", emoji: "⚡", label: "Energized", color: "#2ecc71", bg: "linear-gradient(135deg,#2ecc71,#1abc9c)" },
  { id: "sad",       emoji: "😢", label: "Sad",       color: "#5b8dee", bg: "linear-gradient(135deg,#5b8dee,#7c4dff)" },
  { id: "romantic",  emoji: "💕", label: "Romantic",  color: "#ff6b9d", bg: "linear-gradient(135deg,#ff6b9d,#c0392b)" },
  { id: "stressed",  emoji: "😤", label: "Stressed",  color: "#a29bfe", bg: "linear-gradient(135deg,#a29bfe,#6c5ce7)" },
  { id: "adventurous",emoji:"🌍", label: "Adventurous",color:"#fd79a8", bg: "linear-gradient(135deg,#fd79a8,#e17055)" },
  { id: "lazy",      emoji: "😴", label: "Lazy",      color: "#b2bec3", bg: "linear-gradient(135deg,#636e72,#2d3436)" },
];

const RECIPES = {
  happy: {
    heading: "Sunshine on a Plate 🌞",
    subheading: "Bright, celebratory dishes that match your great vibes.",
    bgWash: "radial-gradient(ellipse 80% 60% at 50% 0%, #4a3200 0%, transparent 70%)",
    items: [
      {
        name: "Mango Sticky Rice",
        emoji: "🥭",
        category: "Dessert",
        desc: "Thai classic with coconut-soaked glutinous rice topped with ripe mango slices and sesame seeds.",
        time: "30 min", serves: "2", difficulty: "Easy",
        ingredients: ["1 cup glutinous rice","1 can coconut milk","2 ripe mangoes","3 tbsp sugar","½ tsp salt","Sesame seeds"],
        steps: [
          "Soak rice overnight, then steam for 20 minutes until translucent.",
          "Warm coconut milk with sugar and salt; do not boil.",
          "Pour ¾ of the coconut sauce over warm rice and let it absorb for 10 minutes.",
          "Slice mangoes into fans and arrange alongside a mound of rice.",
          "Drizzle reserved sauce over the top and finish with sesame seeds."
        ]
      },
      {
        name: "Rainbow Summer Rolls",
        emoji: "🌈",
        category: "Appetizer",
        desc: "Rice paper wrapped around crunchy veggies, herbs, and shrimp with a peanut dipping sauce.",
        time: "25 min", serves: "4", difficulty: "Easy",
        ingredients: ["8 rice paper sheets","200g cooked shrimp","Avocado","Cucumber","Carrot","Fresh mint","Peanut sauce"],
        steps: [
          "Julienne all vegetables into thin 3-inch strips.",
          "Dip one rice paper sheet in warm water for 10 seconds until pliable.",
          "Lay on a damp surface; layer vegetables, shrimp, and mint in the centre.",
          "Fold in the sides, then roll tightly from the bottom.",
          "Serve immediately with peanut dipping sauce."
        ]
      },
      {
        name: "Lemon Ricotta Pancakes",
        emoji: "🥞",
        category: "Breakfast",
        desc: "Fluffy, cloud-like pancakes with bright lemon zest and creamy ricotta for a feel-good morning.",
        time: "20 min", serves: "2", difficulty: "Easy",
        ingredients: ["1 cup ricotta","2 eggs","½ cup flour","Zest of 1 lemon","2 tbsp sugar","Butter","Maple syrup"],
        steps: [
          "Whisk ricotta, eggs, lemon zest, and sugar until smooth.",
          "Fold in flour gently; the batter should be thick and lumpy.",
          "Heat butter in a non-stick pan over medium-low heat.",
          "Drop ¼-cup scoops and cook 3 minutes until bubbles form, then flip.",
          "Serve stacked with maple syrup and extra zest."
        ]
      }
    ]
  },

  cozy: {
    heading: "Warm Hugs & Comfort Food 🍂",
    subheading: "Soul-soothing recipes for when you need to feel held.",
    bgWash: "radial-gradient(ellipse 80% 60% at 50% 0%, #3d1a0a 0%, transparent 70%)",
    items: [
      {
        name: "Butternut Squash Soup",
        emoji: "🎃",
        category: "Soup",
        desc: "Velvety roasted squash blended with warming spices, finished with cream and toasted pepitas.",
        time: "45 min", serves: "4", difficulty: "Easy",
        ingredients: ["1 large butternut squash","1 onion","4 garlic cloves","600ml vegetable broth","Cream","Nutmeg","Pepitas"],
        steps: [
          "Halve the squash, brush with oil, and roast at 200°C for 35 minutes until caramelised.",
          "Sauté onion and garlic until soft and golden.",
          "Scoop squash flesh into the pot with broth; simmer 10 minutes.",
          "Blend until completely smooth; season with nutmeg, salt, and pepper.",
          "Stir in cream and serve topped with pepitas and a swirl of cream."
        ]
      },
      {
        name: "Cheesy Baked Mac",
        emoji: "🧀",
        category: "Pasta",
        desc: "A four-cheese bechamel-drenched macaroni with a golden panko crust — the ultimate comfort.",
        time: "50 min", serves: "6", difficulty: "Medium",
        ingredients: ["400g macaroni","Cheddar","Gruyère","Parmesan","Butter","Flour","Milk","Dijon mustard","Panko breadcrumbs"],
        steps: [
          "Cook pasta until just al dente; it will continue cooking in the oven.",
          "Melt butter, whisk in flour to make a roux, then gradually add warm milk.",
          "Stir in grated cheeses and a spoon of Dijon; season well.",
          "Combine with pasta and pour into a baking dish.",
          "Top with breadcrumbs and Parmesan; bake 25 min at 180°C until golden."
        ]
      },
      {
        name: "Chai-Spiced Oatmeal",
        emoji: "☕",
        category: "Breakfast",
        desc: "Stovetop oats simmered in spiced chai milk, topped with honey, banana, and warming cardamom.",
        time: "15 min", serves: "1", difficulty: "Easy",
        ingredients: ["½ cup rolled oats","1 cup chai tea (brewed)","½ cup milk","Cardamom","Cinnamon","1 banana","Honey"],
        steps: [
          "Brew chai tea and mix with milk in a small saucepan.",
          "Add oats and bring to a simmer, stirring occasionally.",
          "Cook 5–7 minutes until thick; add cardamom and cinnamon.",
          "Pour into a bowl and top with sliced banana and a generous drizzle of honey.",
          "Sprinkle extra cinnamon and serve while piping hot."
        ]
      }
    ]
  },

  energized: {
    heading: "Fuel Your Fire 🔥",
    subheading: "Power-packed meals to keep you charging through the day.",
    bgWash: "radial-gradient(ellipse 80% 60% at 50% 0%, #0a2e1a 0%, transparent 70%)",
    items: [
      {
        name: "Green Power Bowl",
        emoji: "🥗",
        category: "Bowl",
        desc: "Quinoa base loaded with roasted broccoli, edamame, avocado, and a zesty tahini dressing.",
        time: "25 min", serves: "2", difficulty: "Easy",
        ingredients: ["1 cup quinoa","1 head broccoli","1 cup edamame","1 avocado","Tahini","Lemon","Garlic","Sesame seeds"],
        steps: [
          "Cook quinoa in salted water for 15 minutes; fluff with a fork.",
          "Toss broccoli florets in olive oil and roast at 220°C for 18 minutes.",
          "Whisk tahini, lemon juice, minced garlic, and water for the dressing.",
          "Build the bowl: quinoa base, broccoli, edamame, and avocado slices.",
          "Drizzle with tahini dressing and finish with sesame seeds."
        ]
      },
      {
        name: "Protein Banana Oat Muffins",
        emoji: "🍌",
        category: "Snack",
        desc: "No added sugar muffins made with ripe bananas, oats, eggs, and Greek yogurt — gym-ready fuel.",
        time: "30 min", serves: "12", difficulty: "Easy",
        ingredients: ["3 ripe bananas","2 cups oats","2 eggs","½ cup Greek yogurt","1 tsp baking powder","Cinnamon","Blueberries"],
        steps: [
          "Preheat oven to 180°C and line a muffin tin.",
          "Blend oats into flour, then mash bananas in a large bowl.",
          "Combine all wet ingredients; fold in oat flour and baking powder.",
          "Gently stir in blueberries without overmixing.",
          "Fill tins ¾ full and bake 22 minutes until a skewer comes out clean."
        ]
      },
      {
        name: "Spicy Tuna Poke Bowl",
        emoji: "🐟",
        category: "Bowl",
        desc: "Sushi-grade tuna cubes tossed in sriracha mayo over sushi rice with crispy toppings.",
        time: "20 min", serves: "2", difficulty: "Medium",
        ingredients: ["250g sushi-grade tuna","2 cups sushi rice","Sriracha","Mayo","Soy sauce","Cucumber","Seaweed","Sesame"],
        steps: [
          "Cook sushi rice with rice vinegar, sugar, and salt; fan until glossy.",
          "Cube tuna into ¾-inch pieces; toss with soy sauce.",
          "Mix sriracha and mayo for spicy sauce; coat tuna gently.",
          "Build bowls: rice first, then tuna, cucumber ribbons, and seaweed.",
          "Finish with sesame seeds, extra sriracha, and a squeeze of lime."
        ]
      }
    ]
  },

  sad: {
    heading: "A Gentle Hug from the Kitchen 💙",
    subheading: "Soft, warming foods that take care of you right now.",
    bgWash: "radial-gradient(ellipse 80% 60% at 50% 0%, #0a0f35 0%, transparent 70%)",
    items: [
      {
        name: "Chicken Noodle Soup",
        emoji: "🍜",
        category: "Soup",
        desc: "The original healer — tender chicken, golden broth, soft noodles, and love in every sip.",
        time: "1 hr", serves: "4", difficulty: "Easy",
        ingredients: ["1 whole chicken","Egg noodles","2 carrots","3 celery stalks","1 onion","Garlic","Thyme","Bay leaf"],
        steps: [
          "Simmer chicken in 2L of water with onion, garlic, and herbs for 45 minutes.",
          "Remove chicken and shred the meat; discard bones.",
          "Strain the broth and return to pot; add sliced carrot and celery.",
          "Cook vegetables 10 minutes, then add noodles and shredded chicken.",
          "Simmer 5 more minutes, season generously, and serve steaming hot."
        ]
      },
      {
        name: "Chocolate Lava Cake",
        emoji: "🍫",
        category: "Dessert",
        desc: "Warm dark chocolate cake with a molten centre — because you deserve something extraordinary today.",
        time: "20 min", serves: "2", difficulty: "Medium",
        ingredients: ["100g dark chocolate","80g butter","2 eggs","2 egg yolks","60g sugar","2 tbsp flour","Cocoa powder","Vanilla"],
        steps: [
          "Preheat oven to 200°C. Butter two ramekins and dust with cocoa.",
          "Melt chocolate and butter together; cool slightly.",
          "Whisk eggs, yolks, and sugar until pale and thick.",
          "Fold chocolate mixture and flour into the egg mix.",
          "Pour into ramekins and bake exactly 12 minutes; the edges should be set, the centre wobbly. Unmould and serve immediately."
        ]
      },
      {
        name: "Creamy Tomato Pasta",
        emoji: "🍝",
        category: "Pasta",
        desc: "Silky, vibrant tomato sauce finished with cream and basil — simple, quick, and deeply satisfying.",
        time: "25 min", serves: "2", difficulty: "Easy",
        ingredients: ["300g spaghetti","1 can crushed tomatoes","3 garlic cloves","Cream","Fresh basil","Parmesan","Chilli flakes"],
        steps: [
          "Cook pasta in generously salted water until al dente.",
          "Sauté garlic in olive oil until fragrant; add tomatoes and chilli.",
          "Simmer sauce 12 minutes until reduced and deepened in colour.",
          "Stir in a splash of cream; season and simmer 2 more minutes.",
          "Toss with pasta, tear in basil, and finish with Parmesan."
        ]
      }
    ]
  },

  romantic: {
    heading: "A Table for Two 🌹",
    subheading: "Elegant, sensuous dishes to share with someone special.",
    bgWash: "radial-gradient(ellipse 80% 60% at 50% 0%, #3d0a1a 0%, transparent 70%)",
    items: [
      {
        name: "Beef Tenderloin & Red Wine Jus",
        emoji: "🥩",
        category: "Main",
        desc: "Pan-seared fillet mignon rested to perfection, with a glossy red wine reduction and herb butter.",
        time: "35 min", serves: "2", difficulty: "Medium",
        ingredients: ["2 fillet mignons","Red wine","Beef stock","Shallots","Thyme","Garlic","Butter","Rosemary"],
        steps: [
          "Pat steaks dry, season generously with salt and pepper, rest 30 minutes.",
          "Sear in a screaming-hot cast iron with oil for 2 minutes each side.",
          "Add butter, garlic, and thyme; baste continuously for 2 minutes.",
          "Rest steaks 8 minutes under foil while you make the jus.",
          "Sauté shallots, deglaze with wine, add stock and reduce by half."
        ]
      },
      {
        name: "Chocolate Fondue",
        emoji: "🫕",
        category: "Dessert",
        desc: "Dark and milk chocolate melted with cream — dip strawberries, marshmallows, and cake for two.",
        time: "15 min", serves: "2", difficulty: "Easy",
        ingredients: ["150g dark chocolate","50g milk chocolate","150ml cream","1 tbsp liqueur","Strawberries","Marshmallows","Banana"],
        steps: [
          "Finely chop both chocolates and place in a heatproof bowl.",
          "Warm cream in a saucepan until it just begins to simmer.",
          "Pour hot cream over chocolate and let sit 1 minute before stirring.",
          "Stir in your chosen liqueur (Cointreau or Baileys work beautifully).",
          "Transfer to a fondue pot or small saucepan on the lowest heat; serve with dippers."
        ]
      },
      {
        name: "Prawn Linguine al Limone",
        emoji: "🍋",
        category: "Pasta",
        desc: "Golden prawns tossed in white wine, lemon, and garlic with silky linguine — sophistication in 20 minutes.",
        time: "20 min", serves: "2", difficulty: "Easy",
        ingredients: ["200g linguine","300g king prawns","White wine","2 lemons","4 garlic cloves","Chilli","Parsley","Parmesan"],
        steps: [
          "Cook linguine in well-salted water until al dente.",
          "Sauté garlic and chilli in olive oil; add prawns and cook 2 minutes.",
          "Deglaze with white wine; let bubble for 1 minute.",
          "Add lemon juice and zest; toss in drained pasta with a splash of pasta water.",
          "Finish with fresh parsley, Parmesan, and extra lemon zest."
        ]
      }
    ]
  },

  stressed: {
    heading: "Breathe. Then Eat. 🌸",
    subheading: "Calming, nourishing dishes to bring you back to earth.",
    bgWash: "radial-gradient(ellipse 80% 60% at 50% 0%, #1a0a35 0%, transparent 70%)",
    items: [
      {
        name: "Lavender Honey Tea Cake",
        emoji: "🌸",
        category: "Baking",
        desc: "A tender, fragrant loaf with dried lavender and honey — the act of baking is as calming as eating it.",
        time: "55 min", serves: "8", difficulty: "Easy",
        ingredients: ["1½ cups flour","2 tbsp dried lavender","3 tbsp honey","2 eggs","½ cup butter","½ cup yogurt","Lemon zest"],
        steps: [
          "Preheat oven to 170°C. Infuse lavender in melted butter for 5 minutes.",
          "Whisk eggs, honey, and yogurt; strain in the lavender butter.",
          "Fold in flour and lemon zest until just combined.",
          "Pour into a lined loaf tin and bake 45 minutes until golden.",
          "Cool completely before drizzling with extra honey."
        ]
      },
      {
        name: "Golden Milk Chia Pudding",
        emoji: "✨",
        category: "Breakfast",
        desc: "Anti-inflammatory turmeric and ginger chia pudding with coconut milk — set overnight, eat peacefully.",
        time: "10 min + overnight", serves: "2", difficulty: "Easy",
        ingredients: ["6 tbsp chia seeds","400ml coconut milk","1 tsp turmeric","½ tsp ginger","2 tbsp maple syrup","Mango to top"],
        steps: [
          "Whisk coconut milk with turmeric, ginger, and maple syrup.",
          "Stir in chia seeds thoroughly to prevent clumping.",
          "Whisk again after 5 minutes, then again after 10 minutes.",
          "Cover and refrigerate overnight or at least 4 hours.",
          "Serve topped with mango slices and a sprinkle of black sesame."
        ]
      },
      {
        name: "Miso Mushroom Ramen",
        emoji: "🍵",
        category: "Soup",
        desc: "Deeply umami broth with shiitake mushrooms, soft-boiled egg, and ramen noodles — pure mindfulness.",
        time: "30 min", serves: "2", difficulty: "Medium",
        ingredients: ["2 portions ramen noodles","4 tbsp white miso","Shiitake mushrooms","Soft-boiled eggs","Scallions","Nori","Sesame oil","Garlic"],
        steps: [
          "Simmer mushrooms and garlic in 800ml water for 15 minutes to build the broth.",
          "Dissolve miso paste in a ladleful of broth, then stir back in.",
          "Cook ramen noodles separately according to packet; drain.",
          "Place noodles in bowls and pour broth over; arrange mushrooms and halved egg.",
          "Finish with scallions, nori, and a few drops of sesame oil."
        ]
      }
    ]
  },

  adventurous: {
    heading: "Passport-Worthy Plates 🌍",
    subheading: "Bold flavours from far-flung corners of the world.",
    bgWash: "radial-gradient(ellipse 80% 60% at 50% 0%, #3d0a2a 0%, transparent 70%)",
    items: [
      {
        name: "Moroccan Lamb Tagine",
        emoji: "🫙",
        category: "Main",
        desc: "Slow-cooked lamb shoulder with preserved lemon, olives, and a heady spice blend — transported instantly.",
        time: "2 hr 30 min", serves: "4", difficulty: "Medium",
        ingredients: ["800g lamb shoulder","Preserved lemon","Green olives","Saffron","Ras el hanout","Onion","Apricots","Almonds"],
        steps: [
          "Brown lamb pieces in olive oil in batches until deeply caramelised.",
          "Sauté onion, then add ras el hanout and saffron; bloom spices for 1 minute.",
          "Add lamb back with enough water to half-submerge; add preserved lemon and apricots.",
          "Cover and simmer on the lowest heat for 2 hours until meltingly tender.",
          "Add olives in the last 10 minutes; garnish with toasted almonds and fresh coriander."
        ]
      },
      {
        name: "Korean Bibimbap",
        emoji: "🇰🇷",
        category: "Bowl",
        desc: "A kaleidoscope of seasoned vegetables, gochujang, fried egg, and rice — mix vigorously before eating.",
        time: "40 min", serves: "2", difficulty: "Medium",
        ingredients: ["2 cups rice","Spinach","Bean sprouts","Carrots","Mushrooms","2 eggs","Gochujang","Sesame oil","Soy sauce"],
        steps: [
          "Cook rice and season while warm with sesame oil.",
          "Blanch and separately season each vegetable with soy and sesame.",
          "Sauté mushrooms with garlic until golden.",
          "Arrange all vegetables in sections over rice in a stone bowl (or regular bowl).",
          "Top with a fried egg and a spoon of gochujang; mix everything together at the table."
        ]
      },
      {
        name: "Peruvian Ceviche",
        emoji: "🦞",
        category: "Starter",
        desc: "Fresh fish 'cooked' in tiger's milk — a punchy lime and ají amarillo cure that explodes with freshness.",
        time: "25 min", serves: "2", difficulty: "Medium",
        ingredients: ["400g sea bass","Juice of 8 limes","Ají amarillo paste","Red onion","Coriander","Celery","Ginger","Sweet potato","Corn"],
        steps: [
          "Cube fish into 1cm pieces; salt generously and refrigerate while you prep.",
          "Blend lime juice, ají amarillo, a chunk of celery, a knob of ginger for tiger's milk.",
          "Rinse fish and combine with tiger's milk; it will turn opaque within 3–5 minutes.",
          "Fold in thinly sliced red onion and torn coriander.",
          "Serve immediately with sliced sweet potato and boiled corn alongside."
        ]
      }
    ]
  },

  lazy: {
    heading: "Minimal Effort, Maximum Satisfaction 😌",
    subheading: "Delicious food that barely asks anything of you.",
    bgWash: "radial-gradient(ellipse 80% 60% at 50% 0%, #1a1a1a 0%, transparent 70%)",
    items: [
      {
        name: "5-Ingredient Pasta Aglio e Olio",
        emoji: "🧄",
        category: "Pasta",
        desc: "The greatest lazy pasta ever made — garlic, olive oil, chilli, Parmesan, and good spaghetti.",
        time: "15 min", serves: "2", difficulty: "Easy",
        ingredients: ["300g spaghetti","6 garlic cloves","Chilli flakes","Extra-virgin olive oil","Parmesan","Parsley","Salt"],
        steps: [
          "Boil spaghetti in heavily salted water until al dente; reserve 1 cup pasta water.",
          "Gently warm sliced garlic in generous olive oil until golden — do not burn.",
          "Add chilli flakes and ¼ cup pasta water; let it emulsify off heat.",
          "Toss drained pasta in the pan, adding more water to create a silky sauce.",
          "Finish with Parmesan and parsley; eat directly from the pan if you want."
        ]
      },
      {
        name: "Sheet Pan Eggs & Veggies",
        emoji: "🍳",
        category: "Breakfast",
        desc: "Throw everything on one tray, crack some eggs, bake. Done. No dishes, no drama.",
        time: "25 min", serves: "2", difficulty: "Easy",
        ingredients: ["4 eggs","Cherry tomatoes","Bell pepper","Zucchini","Feta","Olive oil","Herbs de Provence","Sourdough"],
        steps: [
          "Preheat oven to 200°C. Toss vegetables with olive oil and herbs.",
          "Spread on a baking sheet and roast 15 minutes until starting to char.",
          "Make wells in the vegetables and crack an egg into each.",
          "Return to oven for 6–8 minutes until whites are set but yolks are still runny.",
          "Crumble feta over everything and serve with thick-cut sourdough toast."
        ]
      },
      {
        name: "Avo Toast, Upgraded",
        emoji: "🥑",
        category: "Snack",
        desc: "The legend — elevated with a soft-boiled egg, chilli oil, and pickled onions. Ready in 10 minutes.",
        time: "10 min", serves: "1", difficulty: "Easy",
        ingredients: ["2 sourdough slices","1 avocado","1 egg","Chilli oil","Quick-pickled red onion","Flaky salt","Lime"],
        steps: [
          "Soft-boil egg for exactly 6.5 minutes; place immediately in ice water.",
          "Toast bread until deeply golden and crunchy.",
          "Mash avocado with lime juice and a pinch of flaky salt.",
          "Spread avocado thickly on toast; peel and halve the egg on top.",
          "Drizzle with chilli oil, add pickled onions, and finish with extra flaky salt."
        ]
      }
    ]
  }
};