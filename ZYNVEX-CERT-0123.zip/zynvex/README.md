# 🍽️ Moodful Bites — Mood-Based Recipe Finder

A beautiful, interactive web app that recommends recipes based on how you're feeling right now.

## 📁 Project Structure

```
mood-recipe-finder/
├── index.html     ← App shell & markup
├── style.css      ← All visual styles & animations
├── data.js        ← Mood + recipe data
├── app.js         ← App logic (rendering, interactions)
└── README.md      ← You're reading this
```

## 🎭 Moods Supported

| Mood        | Theme                          |
|-------------|-------------------------------|
| 😄 Happy    | Bright, celebratory dishes    |
| 🤗 Cozy     | Warm comfort food             |
| ⚡ Energized | Power-packed fuel             |
| 😢 Sad      | Soothing, healing food        |
| 💕 Romantic | Elegant dishes for two        |
| 😤 Stressed | Calming, mindful eating       |
| 🌍 Adventurous | Global cuisine             |
| 😴 Lazy     | Minimal effort, max reward    |

## 🚀 How to Run

Just open `index.html` in any modern browser — no build tools, no dependencies, no server required.

```bash
# Option 1: Open directly
open index.html

# Option 2: Simple local server (Python)
python3 -m http.server 8080
# Then visit http://localhost:8080

# Option 3: VS Code Live Server extension
# Right-click index.html → "Open with Live Server"
```

## ✨ Features

- **8 moods** with 3 recipes each (24 recipes total)
- **Animated mood orbs** with smooth transitions
- **Background wash** shifts colour per mood
- **Recipe cards** with animated entry
- **Full recipe modal** with ingredients + step-by-step method
- **Fully responsive** — works on mobile, tablet, desktop
- **No frameworks** — pure HTML, CSS, and vanilla JS

## 🛠️ Customisation

### Add a new mood
In `data.js`, add to the `MOODS` array:
```js
{ id: "excited", emoji: "🎉", label: "Excited", color: "#ff6b6b", bg: "linear-gradient(135deg,#ff6b6b,#ee5a24)" }
```
Then add a matching key in `RECIPES`:
```js
excited: {
  heading: "Party Food! 🎉",
  subheading: "Dishes as exciting as you feel.",
  bgWash: "radial-gradient(...)",
  items: [ /* your recipes */ ]
}
```

### Add a recipe to an existing mood
Find the mood in `RECIPES[moodId].items` and push a new object:
```js
{
  name: "Recipe Name",
  emoji: "🍕",
  category: "Category",
  desc: "Short description.",
  time: "20 min", serves: "2", difficulty: "Easy",
  ingredients: ["item 1", "item 2"],
  steps: ["Step one.", "Step two."]
}
```

## 🎨 Design Tokens (in style.css)

```css
:root {
  --bg:        #0f0c1a;   /* page background */
  --surface:   #1c1730;   /* card background */
  --surface2:  #261f42;   /* elevated surface */
  --text:      #f0ebff;   /* primary text */
  --muted:     #9b93b8;   /* secondary text */
  --accent:    #f5a623;   /* amber highlight */
  --radius:    16px;
}
```